Trong bài tập này em đã tạo một trang HTML cơ bản để hiển thị thông tin lịch học cá nhân.
Đầu tiên em xây dựng phần header và section để giới thiệu thông tin sinh viên (họ tên, MSSV, ảnh chân dung).
Tiếp đó em sử dụng thẻ <table> kết hợp <caption>, <thead>, <tbody> để trình bày thời khóa biểu gồm các cột: Tên môn học, Tên giảng viên, Ngày giờ học, Phòng học.
Dữ liệu trong bảng em lấy từ hệ thống QLĐT và lọc ra thông tin cần thiết, loại bỏ các thay đổi hoặc chú thích phụ.
Cuối cùng em thêm phần footer có MSSV và ngày tạo để hoàn chỉnh trang theo yêu cầu.
Toàn bộ mã được viết thuần HTML, có thể mở trực tiếp bằng trình duyệt và không cần thêm thư viện ngoài.